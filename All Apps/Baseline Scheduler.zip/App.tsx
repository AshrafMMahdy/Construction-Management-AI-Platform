import React, { useState, useCallback } from 'react';
import { Activity, AgentOutput, ProjectInput, ProjectFeatures } from './types';
import FileUpload from './components/FileUpload';
import ProjectForm from './components/ProjectForm';
import ScheduleTable from './components/ScheduleTable';
import NarrativeDisplay from './components/NarrativeDisplay';
import Spinner from './components/Spinner';
import EvaluationTable from './components/EvaluationTable';
import { generateFinalSchedule } from './services/aiService';
import { parseDataAndExtractFeatures } from './utils/dataParser';
import { WandIcon, DownloadIcon, UsersIcon } from './components/IconComponents';

type LoadingStep = 'idle' | 'parsing' | 'agentsRunning' | 'leaderRunning' | 'done';

const App: React.FC = () => {
  const [historicalData, setHistoricalData] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const [projectFeatures, setProjectFeatures] = useState<ProjectFeatures | null>(null);

  const initialProjectInput: ProjectInput = {
    isNotInDb: false,
    description: '',
    selections: {},
  };
  const [projectInput, setProjectInput] = useState<ProjectInput>(initialProjectInput);
  
  const [agentOutputs, setAgentOutputs] = useState<AgentOutput[] | null>(null);
  const [generatedSchedule, setGeneratedSchedule] = useState<Activity[] | null>(null);
  const [generatedNarrative, setGeneratedNarrative] = useState<string | null>(null);

  const [loadingStep, setLoadingStep] = useState<LoadingStep>('idle');
  const [error, setError] = useState<string | null>(null);
  
  const isLoading = loadingStep !== 'idle' && loadingStep !== 'done';

  const handleFileLoad = useCallback((content: string, name: string) => {
    setLoadingStep('parsing');
    setError(null);
    setAgentOutputs(null);
    setGeneratedSchedule(null);
    setGeneratedNarrative(null);
    setProjectFeatures(null);

    try {
      const { features } = parseDataAndExtractFeatures(content, name);
      setHistoricalData(content);
      setFileName(name);
      setProjectFeatures(features);

      // Initialize projectInput with default selections from the extracted features
      const defaultSelections: Record<string, string> = {};
      for (const key in features) {
          if (features[key].length > 0) {
              defaultSelections[key] = features[key][0];
          }
      }
      setProjectInput({ ...initialProjectInput, selections: defaultSelections });

    } catch (e) {
        if (e instanceof Error) {
            setError(`Error parsing file: ${e.message}`);
        } else {
            setError('An unknown error occurred during file parsing.');
        }
    } finally {
        setLoadingStep('idle');
    }
  }, []);

  const handleGenerateClick = async () => {
    if (!historicalData) {
      setError('Please upload historical project data first.');
      return;
    }
    
    setError(null);
    setAgentOutputs(null);
    setGeneratedSchedule(null);
    setGeneratedNarrative(null);

    try {
      setLoadingStep('agentsRunning');
      const { agentOutputs: newAgentOutputs, finalSchedule } = await generateFinalSchedule(
          historicalData,
          projectInput,
          () => setLoadingStep('leaderRunning')
      );
      
      setAgentOutputs(newAgentOutputs);
      setGeneratedSchedule(finalSchedule.schedule);
      setGeneratedNarrative(finalSchedule.narrative);

    } catch (err) {
      if (err instanceof Error) {
        setError(`An unexpected error occurred: ${err.message}`);
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setLoadingStep('done');
    }
  };
  
  const handleDownloadCSV = () => {
    if (!generatedSchedule) return;
    const headers = ["ID", "Name", "Duration", "Predecessors"];
    const toCsvField = (value: string | number) => {
        const str = String(value);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
            return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
    };
    const rows = generatedSchedule.map(act => 
        [act.id, toCsvField(act.name), act.duration, toCsvField(act.predecessors)].join(',')
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    const safeFileName = projectInput.description.substring(0, 30).replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'project';
    link.setAttribute("download", `schedule_${safeFileName}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const isButtonDisabled = isLoading || !historicalData || (projectInput.isNotInDb && !projectInput.description.trim());
  
  const loadingMessages: Record<LoadingStep, { title: string; subtitle: string; icon: React.ReactNode }> = {
      idle: { title: "", subtitle: "", icon: null },
      done: { title: "", subtitle: "", icon: null },
      parsing: { title: "Parsing File...", subtitle: "Extracting features and validating data.", icon: <Spinner /> },
      agentsRunning: { title: "Agents at Work...", subtitle: "Local agents are generating schedule proposals based on historical data.", icon: <Spinner /> },
      leaderRunning: { title: "Leader Agent Synthesizing...", subtitle: "The lead agent is analyzing proposals to create the final, optimized schedule.", icon: <Spinner /> },
  }

  return (
    <div className="min-h-screen bg-brand-primary font-sans">
      <header className="bg-brand-secondary/50 p-4 border-b border-brand-accent/20">
        <h1 className="text-2xl font-bold text-center text-brand-light">
          AI Construction Scheduler (Multi-Agent)
        </h1>
        <p className="text-center text-brand-muted text-sm mt-1">
          Using a team of AI agents and a lead agent to build your project plan.
        </p>
      </header>
      
      <main className="p-4 md:p-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          <div className="lg:col-span-4 bg-brand-secondary rounded-xl shadow-2xl p-6 h-fit flex flex-col gap-8">
            <FileUpload onFileLoad={handleFileLoad} fileName={fileName} disabled={isLoading} />
            {historicalData && projectFeatures && (
                <ProjectForm 
                    projectInput={projectInput} 
                    onInputChange={setProjectInput} 
                    projectFeatures={projectFeatures}
                    disabled={isLoading} 
                />
            )}
            <div className="mt-2">
              <button
                onClick={handleGenerateClick}
                disabled={isButtonDisabled}
                className={`w-full flex items-center justify-center gap-2 text-lg font-bold py-3 px-6 rounded-lg transition-all duration-300 ease-in-out shadow-lg
                  ${isButtonDisabled 
                    ? 'bg-brand-muted/40 text-brand-muted cursor-not-allowed' 
                    : 'bg-brand-accent text-brand-primary hover:bg-yellow-400 transform hover:-translate-y-1'}`
                }
              >
                {isLoading ? <Spinner /> : <WandIcon className="w-6 h-6" />}
                <span>{isLoading ? 'Generating...' : 'Generate Schedule'}</span>
              </button>
            </div>
            {error && <div className="mt-4 text-center p-3 bg-red-900/50 border border-red-700 text-red-300 rounded-md">{error}</div>}
          </div>

          <div className="lg:col-span-8 flex flex-col gap-8">
            {!isLoading && !agentOutputs && (
              <div className="flex flex-col items-center justify-center text-center bg-brand-secondary rounded-xl shadow-2xl p-10 min-h-[400px]">
                <UsersIcon className="w-16 h-16 text-brand-muted mb-4"/>
                <h2 className="text-2xl font-bold text-brand-light">Ready to Build Your Schedule</h2>
                <p className="text-brand-muted mt-2 max-w-md">
                  Upload your data, define your project, and let the AI agent team do the heavy lifting.
                </p>
              </div>
            )}
            {isLoading && (
              <div className="flex flex-col items-center justify-center text-center bg-brand-secondary rounded-xl shadow-2xl p-10 min-h-[400px]">
                  {loadingMessages[loadingStep].icon}
                  <h2 className="text-2xl font-bold text-brand-light mt-6">{loadingMessages[loadingStep].title}</h2>
                  <p className="text-brand-muted mt-2 max-w-md">{loadingMessages[loadingStep].subtitle}</p>
                  {loadingStep === 'leaderRunning' && agentOutputs && <EvaluationTable agentOutputs={agentOutputs} />}
              </div>
            )}
            {!isLoading && agentOutputs && generatedSchedule && (
              <div className="flex flex-col gap-8">
                <div>
                  <h2 className="text-2xl font-bold text-brand-accent mb-4">Agent Performance Evaluation</h2>
                  <EvaluationTable agentOutputs={agentOutputs} />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-4 mt-4">
                    <h2 className="text-2xl font-bold text-brand-accent">Final Synthesized Schedule</h2>
                    <button
                        onClick={handleDownloadCSV}
                        className="flex items-center gap-2 py-2 px-4 bg-brand-secondary hover:bg-brand-muted/20 text-brand-light font-semibold rounded-lg transition-colors border border-brand-muted"
                        aria-label="Download schedule as CSV"
                    >
                        <DownloadIcon className="w-5 h-5" />
                        <span>Download CSV</span>
                    </button>
                  </div>
                  <ScheduleTable activities={generatedSchedule} />
                </div>
                
                {generatedNarrative && (
                  <div>
                    <NarrativeDisplay narrative={generatedNarrative} />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
